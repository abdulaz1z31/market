export class CreateProductDto {
  name: string;
  price: number;
  info: string;
  is_active: boolean;
  quantity: number;
}
