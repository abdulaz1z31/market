export enum userRoles {
  user = 'user',
  admin = 'admin',
  seller = 'seller',
}
