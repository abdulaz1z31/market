export class CreateOrderProductDto {
  order: { id: number };
  product: { id: number };
}
